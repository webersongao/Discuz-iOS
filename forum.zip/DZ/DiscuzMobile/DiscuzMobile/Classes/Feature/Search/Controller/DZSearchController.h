//
//  DZSearchController.h
//  DiscuzMobile
//
//  Created by HB on 16/4/15.
//  Copyright © 2016年 comsenz-service.com. All rights reserved.
//

#import "DZBaseTableViewController.h"

@interface DZSearchController : DZBaseTableViewController
@end
