//
//  MessageDetailCell.h
//  DiscuzMobile
//
//  Created by gensinimac1 on 15/7/6.
//  Copyright (c) 2015年 comsenz-service.com. All rights reserved.
//

#import "DZBaseTableViewCell.h"

@class CellFrameModel;

@interface MessageDetailCell : DZBaseTableViewCell

@property (nonatomic, strong) CellFrameModel *cellFrame;

@end
