//
//  DZMsgChatDetailController.h
//  DiscuzMobile
//
//  Created by ZhangJitao on 2018/7/2.
//  Copyright © 2018年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseViewController.h"

@interface DZMsgChatDetailController : DZBaseViewController
@property (nonatomic, copy) NSString *touid;
@property (nonatomic, copy) NSString *username;
@property (nonatomic, copy) NSString *nametitle;
@end
