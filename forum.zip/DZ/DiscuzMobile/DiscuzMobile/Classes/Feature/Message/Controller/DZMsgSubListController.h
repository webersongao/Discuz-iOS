//
//  DZMsgSubListController.h
//  DiscuzMobile
//
//  Created by HB on 2017/7/17.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewController.h"
@class PmTypeModel;

@interface DZMsgSubListController : DZBaseTableViewController

@property (nonatomic, strong) PmTypeModel *typeModel;

@end
