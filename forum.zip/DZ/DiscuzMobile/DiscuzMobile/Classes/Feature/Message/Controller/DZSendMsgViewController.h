//
//  DZSendMsgViewController.h
//  DiscuzMobile
//
//  Created by gensinimac1 on 15/5/12.
//  Copyright (c) 2015年 comsenz-service.com. All rights reserved.
//

#import "DZBaseViewController.h"

@interface DZSendMsgViewController : DZBaseViewController

@property (nonatomic , copy) NSString * uid;
@property (nonatomic , copy) NSString * otherusername;
@property (nonatomic ,strong)UITextField * titleTextField;
@end
