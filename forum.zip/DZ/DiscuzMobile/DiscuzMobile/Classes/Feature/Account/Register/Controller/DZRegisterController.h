//
//  DZRegisterController.h
//  DiscuzMobile
//
//  Created by HB on 17/1/11.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import "DZLoginBaseController.h"

@interface DZRegisterController : DZLoginBaseController

@end
