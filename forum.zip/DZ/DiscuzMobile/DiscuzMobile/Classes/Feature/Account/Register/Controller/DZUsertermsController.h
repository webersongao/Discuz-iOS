//
//  DZUsertermsController.h
//  DiscuzMobile
//
//  Created by HB on 17/3/8.
//  Copyright © 2017年 comsenz-service.com. All rights reserved.
//

#import "DZBaseViewController.h"

@interface DZUsertermsController : DZBaseViewController

@end
