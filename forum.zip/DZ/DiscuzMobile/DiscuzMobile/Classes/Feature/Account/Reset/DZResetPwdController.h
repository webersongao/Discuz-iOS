//
//  DZResetPwdController.h
//  DiscuzMobile
//
//  Created by ZhangJitao on 2018/7/17.
//  Copyright © 2018年 comsenz-service.com.  All rights reserved.
//

#import "DZLoginBaseController.h"

@interface DZResetPwdController : DZLoginBaseController

@end
