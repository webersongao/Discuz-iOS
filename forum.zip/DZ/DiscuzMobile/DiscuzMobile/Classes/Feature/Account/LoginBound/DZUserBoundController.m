//
//  DZUserBoundController.m
//  DiscuzMobile
//
//  Created by HB on 16/9/18.
//  Copyright © 2016年 comsenz-service.com. All rights reserved.
//

#import "DZUserBoundController.h"
#import "DZLoginTextField.h"
#import "DZAuthCodeView.h"
#import "DZUserBoundView.h"
#import "DZLoginNetTool.h"

@interface DZUserBoundController () <UITextFieldDelegate>

@property (nonatomic,strong) DZUserBoundView *boundView;

@end

@implementation DZUserBoundController

- (void)loadView {
    [super loadView];
    _boundView = [[DZUserBoundView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.view = _boundView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _boundView.delegate = self;
    _boundView.contentSize = CGSizeMake(KScreenWidth, KScreenHeight + 1);
    self.dz_NavigationItem.title = @"登录绑定";
    self.view.backgroundColor = mRGBColor(246, 246, 246);
    
    [self setAction];
}

- (void)setAction {
    _boundView.authCodeField.delegate = self;
    _boundView.nameField.delegate = self;
    _boundView.passwordField.delegate = self;
    _boundView.authCodeField.delegate = self;
    [_boundView.boundBtn addTarget:self action:@selector(boundBtnClick) forControlEvents:UIControlEventTouchUpInside];
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (textField.tag == 103) {
        [self isCodeRight];
    }
}


- (BOOL)isCodeRight {
    // 忽略大小写
    BOOL result = [_boundView.authCodeField.text compare:_boundView.codeView.authCodeStr
                                                 options:NSCaseInsensitiveSearch | NSNumericSearch] == NSOrderedSame;
    if (![DataCheck isValidString:_boundView.authCodeField.text]) {
        [MBProgressHUD showInfo:@"请输入验证码"];
        //验证不匹配，验证码和输入框抖动
        CAKeyframeAnimation *anim = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation.x"];
        anim.repeatCount = 1;
        anim.values = @[@-20,@20,@-20];
        //        [DZAuthCodeView.layer addAnimation:anim forKey:nil];
        [_boundView.authCodeField.layer addAnimation:anim forKey:nil];
    } else {
        //判断输入的是否为验证图片中显示的验证码
        if (!result) {
            [MBProgressHUD showInfo:@"验证码不正确"];
            //验证不匹配，验证码和输入框抖动
            CAKeyframeAnimation *anim = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation.x"];
            anim.repeatCount = 1;
            anim.values = @[@-20,@20,@-20];
            //        [DZAuthCodeView.layer addAnimation:anim forKey:nil];
            [_boundView.authCodeField.layer addAnimation:anim forKey:nil];
        }
    }
    return result;
}

- (void)boundBtnClick {
    [self.view endEditing:YES];
    
    NSString *name = _boundView.nameField.text;
    NSString *pass = _boundView.passwordField.text;
    NSString *code = _boundView.authCodeField.text;
    
    if ([DataCheck isValidString:name]
        && [DataCheck isValidString:pass]
        //        && [DataCheck isValidString:code]
        ) {
        if ([self isCodeRight]) {
            [self boundData];
        }
    } else {
        if (![DataCheck isValidString:name]) {
            [MBProgressHUD showInfo:@"请输入用户"];
        } else if (![DataCheck isValidString:pass]) {
            [MBProgressHUD showInfo:@"请输入密码"];
        }
        //        else if (![DataCheck isValidString:code]) {
        //            [MBProgressHUD showInfo:@"请输入验证码"];
        //        }
    }
}

- (void)boundData {
    NSString *name = _boundView.nameField.text;
    NSString *pass = _boundView.passwordField.text;
    
    if (![DZShareCenter shareInstance].bloginModel.openid.length) {
        [DZMobileCtrl showAlertError:@"openid异常，微信绑定失败"];
        return;
    }
    [self.HUD showLoadingMessag:@"登录中" toView:self.view];
    [DZLoginNetTool DZ_WeixinLoginWithName:name passWord:pass completion:^(DZLoginResModel *resModel) {
        [self.HUD hideAnimated:YES];
        if (resModel) {
            [self updateUserResInfo:resModel];
        }else{
            [DZMobileCtrl showAlertError:@"微信绑定失败"];
        }
    }];
    
}

@end
