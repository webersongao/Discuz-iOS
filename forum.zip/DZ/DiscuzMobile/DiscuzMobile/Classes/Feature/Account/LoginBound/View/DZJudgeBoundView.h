//
//  DZJudgeBoundView.h
//  DiscuzMobile
//
//  Created by HB on 16/10/27.
//  Copyright © 2016年 comsenz-service.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DZJudgeBoundView : UIScrollView

@property (nonatomic,strong) UIImageView *headView;
@property (nonatomic,strong) UILabel *desclabl;
@property (nonatomic,strong) UIButton *registerBtn;
@property (nonatomic,strong) UIButton *boundBtn;

@end
