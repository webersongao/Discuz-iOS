//
//  DZJudgeBoundController.h
//  DiscuzMobile
//
//  Created by HB on 16/9/18.
//  Copyright © 2016年 comsenz-service.com. All rights reserved.
//

#import "DZLoginBaseController.h"

@interface DZJudgeBoundController : DZLoginBaseController

@end
