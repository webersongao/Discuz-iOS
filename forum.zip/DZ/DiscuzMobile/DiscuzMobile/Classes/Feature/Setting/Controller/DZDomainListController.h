//
//  DZDomainListController.h
//  DiscuzMobile
//
//  Created by ZhangJitao on 2018/3/30.
//  Copyright © 2018年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewController.h"

@interface DZDomainListController : DZBaseTableViewController

@end
