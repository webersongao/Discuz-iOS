//
//  DZAboutController.h
//  DiscuzMobile
//
//  Created by HB on 16/12/5.
//  Copyright © 2016年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseViewController.h"

@interface DZAboutController : DZBaseViewController

@end
