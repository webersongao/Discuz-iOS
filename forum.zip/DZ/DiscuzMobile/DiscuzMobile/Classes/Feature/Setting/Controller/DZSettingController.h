//
//  DZSettingController.h
//  DiscuzMobile
//
//  Created by gensinimac1 on 15/5/5.
//  Copyright (c) 2015年 comsenz-service.com. All rights reserved.
//

#import "DZBaseTableViewController.h"

@interface DZSettingController : DZBaseTableViewController

@end
