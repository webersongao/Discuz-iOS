//
//  DZFastPostController.h
//  DiscuzMobile
//
//  Created by WebersonGao on 2019/12/27.
//  Copyright © 2019 comsenz-service.com. All rights reserved.
//

#import "DZBaseViewController.h"


@interface DZFastPostController : DZBaseViewController

@end

