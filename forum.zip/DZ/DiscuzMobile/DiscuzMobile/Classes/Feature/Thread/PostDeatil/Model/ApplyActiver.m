//
//  ApplyActiver.m
//  DiscuzMobile
//
//  Created by HB on 2017/7/28.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import "ApplyActiver.h"

@implementation ApplyActiver

-(void)setDateline:(NSString *)dateline{
    _dateline = [dateline transformationStr];
}






@end
