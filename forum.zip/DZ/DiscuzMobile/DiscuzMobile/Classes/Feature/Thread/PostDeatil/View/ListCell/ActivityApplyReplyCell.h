//
//  ActivityApplyReplyCell.h
//  DiscuzMobile
//
//  Created by HB on 2017/7/31.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewCell.h"

@interface ActivityApplyReplyCell : DZBaseTableViewCell

@property (nonatomic, strong) UILabel *tipLab;
@property (nonatomic, strong) UITextView *detailView;

@end
