//
//  ApplyItemView.h
//  DiscuzMobile
//
//  Created by HB on 2017/7/28.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ApplyStatusView.h"

@interface ApplyItemView : UIView

@property (nonatomic, strong) UILabel *tipLab;
@property (nonatomic, strong) ApplyStatusView *infoLab;

@end
