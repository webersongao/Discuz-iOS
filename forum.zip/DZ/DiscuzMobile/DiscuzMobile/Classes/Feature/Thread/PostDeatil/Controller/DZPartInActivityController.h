//
//  DZPartInActivityController.h
//  DiscuzMobile
//
//  Created by HB on 2017/8/4.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewController.h"
#import "ThreadModel.h"


@interface DZPartInActivityController : DZBaseTableViewController

@property (nonatomic, strong) ThreadModel *threadModel;

@end
