//
//  PartInSexCell.h
//  DiscuzMobile
//
//  Created by HB on 2017/8/4.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewCell.h"
#import "DZSelectTipView.h"

@interface PartInSexCell : DZBaseTableViewCell

@property (nonatomic, strong) UILabel *titleLab;
@property (nonatomic, strong) DZSelectTipView *sexSelectView;

@end
