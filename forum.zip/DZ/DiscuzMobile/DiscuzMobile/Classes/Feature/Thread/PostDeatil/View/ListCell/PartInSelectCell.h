//
//  PartInSelectCell.h
//  DiscuzMobile
//
//  Created by HB on 2017/8/4.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewCell.h"

@interface PartInSelectCell : DZBaseTableViewCell

@property (nonatomic, strong) UILabel *titleLab;

@end
