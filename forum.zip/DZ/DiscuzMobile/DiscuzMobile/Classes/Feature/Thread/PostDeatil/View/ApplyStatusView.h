//
//  ApplyStatusView.h
//  DiscuzMobile
//
//  Created by HB on 2017/7/28.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ApplyStatusView : UIView

@property (nonatomic, strong) UILabel *statusLab;
- (void)setStatusText:(NSString *)text;

@end
