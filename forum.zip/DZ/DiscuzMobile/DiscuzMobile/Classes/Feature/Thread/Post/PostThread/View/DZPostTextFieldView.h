//
//  DZPostTextFieldView.h
//  DiscuzMobile
//
//  Created by HB on 17/4/24.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DZPostTextFieldView : UIView

@property (nonatomic, strong) UITextField *textField;

@end
