//
//  DZSelectTipView.h
//  DiscuzMobile
//
//  Created by HB on 2017/7/27.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DZSelectTipView : UIView

@property (nonatomic, strong) UILabel *tipLab;
@property (nonatomic, strong) UIButton *button;

@end
