//
//  DZAudioListCell.h
//  DiscuzMobile
//
//  Created by HB on 2017/6/8.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewCell.h"

@interface DZAudioListCell : DZBaseTableViewCell

@property (nonatomic, strong) UIImageView *audioIv;
@property (nonatomic, strong) UILabel *timeLabel;


@end
