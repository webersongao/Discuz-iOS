//
//  DZVoteTitleCell.h
//  DiscuzMobile
//
//  Created by HB on 16/11/30.
//  Copyright © 2016年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewCell.h"
#import "DZBaseTextField.h"

@interface DZVoteTitleCell : DZBaseTableViewCell

@property (nonatomic, strong) UITextField *titleTextField;

@end
