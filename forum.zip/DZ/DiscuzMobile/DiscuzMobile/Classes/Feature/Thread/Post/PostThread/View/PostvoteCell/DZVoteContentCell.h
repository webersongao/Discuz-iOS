//
//  DZVoteContentCell.h
//  DiscuzMobile
//
//  Created by HB on 16/11/30.
//  Copyright © 2016年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewCell.h"


@interface DZVoteContentCell : DZBaseTableViewCell

@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) UIButton *postImageBtn;

@end
