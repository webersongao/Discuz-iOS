//
//  DZViewpointCell.m
//  DiscuzMobile
//
//  Created by HB on 2017/6/23.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import "DZViewpointCell.h"

@implementation DZViewpointCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self commitInit];
    }
    return self;
}

- (void)commitInit {
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.positiveLab.text = @"正方观点";
    [self.contentView addSubview:self.positiveLab];
    self.oppositeLab.text = @"反方观点";
    [self.contentView addSubview:self.oppositeLab];
    [self.contentView addSubview:self.positiveTextView];
    [self.contentView addSubview:self.oppositeTextView];
}


- (void)layoutSubviews {
    [super layoutSubviews];
    self.positiveLab.frame = CGRectMake(10, 10, 200, 20);
    self.positiveTextView.frame  = CGRectMake(CGRectGetMinX(self.positiveLab.frame), CGRectGetMaxY(self.positiveLab.frame) + 10, KScreenWidth - 20, 80); // 120
    self.positiveTextView.layer.cornerRadius = 4;
    
    self.oppositeLab.frame  = CGRectMake(CGRectGetMinX(self.positiveTextView.frame), CGRectGetMaxY(self.positiveTextView.frame) + 15, CGRectGetWidth(self.positiveLab.frame), CGRectGetHeight(self.positiveLab.frame)); // 155
    self.oppositeTextView.frame = CGRectMake(CGRectGetMinX(self.oppositeLab.frame), CGRectGetMaxY(self.oppositeLab.frame) + 10, KScreenWidth - 20, 80); // 245
    self.oppositeTextView.layer.cornerRadius = 4;
    
}


- (UILabel *)positiveLab {
    if (_positiveLab == nil) {
        _positiveLab = [self getTypeLabel];
    }
    return _positiveLab;
}

- (UILabel *)oppositeLab {
    if (_oppositeLab == nil) {
        _oppositeLab = [self getTypeLabel];
    }
    return _oppositeLab;
}

- (DZPlaceholderTextView *)positiveTextView {
    if (_positiveTextView == nil) {
        _positiveTextView = [self getTypeTextview];
    }
    return _positiveTextView;
}

- (DZPlaceholderTextView *)oppositeTextView {
    if (_oppositeTextView == nil) {
        _oppositeTextView = [self getTypeTextview];
    }
    return _oppositeTextView;
}

- (UILabel *)getTypeLabel {
    UILabel *lab = [[UILabel alloc] init];
    lab.font = [DZFontSize HomecellTitleFontSize15];
    lab.textAlignment = NSTextAlignmentLeft;
    return lab;
}
- (DZPlaceholderTextView *)getTypeTextview {
    DZPlaceholderTextView *textview = [[DZPlaceholderTextView alloc] init];
    textview.placeholder = @"  请输入投票选项";
    textview.layer.borderWidth = 1;
    textview.layer.masksToBounds = YES;
    textview.layer.borderColor = K_Color_Line.CGColor;
    textview.font = [DZFontSize HomecellTitleFontSize15];
    return textview;
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
