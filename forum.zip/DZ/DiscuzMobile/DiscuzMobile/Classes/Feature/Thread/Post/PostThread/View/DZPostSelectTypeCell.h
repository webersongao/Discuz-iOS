//
//  DZPostSelectTypeCell.h
//  DiscuzMobile
//
//  Created by HB on 17/4/25.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewCell.h"

@interface DZPostSelectTypeCell : DZBaseTableViewCell

@property (nonatomic, strong) UITextField *selectField;

@end
