//
//  ActiveExtendCell.h
//  DiscuzMobile
//
//  Created by HB on 2017/7/27.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewCell.h"

@interface ActiveExtendCell : DZBaseTableViewCell

@property (nonatomic, strong) UITextField *integralTextfield;
@property (nonatomic, strong) UITextField *costTextfield;
@property (nonatomic, strong) UITextField *signupEndTextfield;

@end
