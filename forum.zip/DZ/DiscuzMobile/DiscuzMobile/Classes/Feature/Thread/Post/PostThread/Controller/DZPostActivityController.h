//
//  DZPostActivityController.h
//  DiscuzMobile
//
//  Created by HB on 2017/7/27.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
// 发起活动

#import "DZPostBaseController.h"

@interface DZPostActivityController : DZPostBaseController

@end
