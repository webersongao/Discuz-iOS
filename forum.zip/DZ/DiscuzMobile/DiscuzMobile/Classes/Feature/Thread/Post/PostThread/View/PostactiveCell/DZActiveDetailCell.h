//
//  DZActiveDetailCell.h
//  DiscuzMobile
//
//  Created by HB on 16/11/30.
//  Copyright © 2016年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewCell.h"
#import "DZPlaceholderTextView.h"

@interface DZActiveDetailCell : DZBaseTableViewCell

@property (nonatomic,strong) DZPlaceholderTextView *detailTextView;

@end
