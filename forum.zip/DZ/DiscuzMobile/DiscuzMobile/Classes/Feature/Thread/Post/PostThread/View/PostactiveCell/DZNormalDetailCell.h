//
//  DZNormalDetailCell.h
//  DiscuzMobile
//
//  Created by ZhangJitao on 2018/6/29.
//  Copyright © 2018年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewCell.h"

@interface DZNormalDetailCell : DZBaseTableViewCell
@property (nonatomic,strong) YYTextView *textView;;
@end
