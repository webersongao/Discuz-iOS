//
//  DZPostNormalController.h
//  DiscuzMobile
//
//  Created by HB on 2017/6/7.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
// 普通发帖

#import "DZPostBaseController.h"

@interface DZPostNormalController : DZPostBaseController

@end
