//
//  DZPostDebateController.h
//  DiscuzMobile
//
//  Created by HB on 2017/6/23.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
// 发起辩论

#import "DZPostBaseController.h"

@interface DZPostDebateController : DZPostBaseController

@end
