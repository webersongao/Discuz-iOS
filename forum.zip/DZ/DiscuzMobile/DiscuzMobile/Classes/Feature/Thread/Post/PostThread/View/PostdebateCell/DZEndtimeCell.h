//
//  DZEndtimeCell.h
//  DiscuzMobile
//
//  Created by HB on 2017/6/23.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import "DZBaseTableViewCell.h"

@interface DZEndtimeCell : DZBaseTableViewCell

@property (nonatomic, strong) UILabel *titleLab;
@property (nonatomic, strong) UITextField *contentTextfield;
@property (nonatomic, strong) UIButton *selectBtn;

@end
