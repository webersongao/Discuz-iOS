//
//  AppDelegate+Launch.h
//  DiscuzMobile
//
//  Created by WebersonGao on 2019/11/21.
//  Copyright © 2019 comsenz-service.com. All rights reserved.
//  欢迎页面

#import "AppDelegate.h"

@interface AppDelegate (Launch)

-(void)launch_WhenApplicationDidBecomeActive;
-(void)loadAppLaunchScreenView;


@end


