//
//  AppDelegate+SDK.m
//  DiscuzMobile
//
//  Created by WebersonGao on 2019/11/14.
//  Copyright © 2019 comsenz-service.com. All rights reserved.
//

#import "AppDelegate+SDK.h"
#import "AppDelegate+Push.h"
#import "AppDelegate+iflyMSC.h"

@implementation AppDelegate (SDK)


-(void)launchSDKConfigWithOptions:(NSDictionary *)launchOptions{
    
    [self launchXFSpeech];
//    [self launchPushConfigration:launchOptions];
}


@end









