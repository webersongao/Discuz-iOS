//
//  AppDelegate+Global.h
//  DiscuzMobile
//
//  Created by WebersonGao on 2019/11/21.
//  Copyright © 2019 comsenz-service.com. All rights reserved.
//  拉取 全局配置数据

#import "AppDelegate.h"

@interface AppDelegate (Global)


-(void)Global_loadForumGlobalInfofromServer;

@end


