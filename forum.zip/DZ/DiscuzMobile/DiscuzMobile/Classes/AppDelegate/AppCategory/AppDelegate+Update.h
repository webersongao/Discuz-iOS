//
//  AppDelegate+Update.h
//  DiscuzMobile
//
//  Created by WebersonGao on 2019/11/21.
//  Copyright © 2019 comsenz-service.com. All rights reserved.
//  版本升级检查

#import "AppDelegate.h"

@interface AppDelegate (Update)

- (void)checkAppDZVersionUpdate;

@end


