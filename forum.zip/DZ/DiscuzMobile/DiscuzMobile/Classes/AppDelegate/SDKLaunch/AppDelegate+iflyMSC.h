//
//  AppDelegate+iflyMSC.h
//  DiscuzMobile
//
//  Created by WebersonGao on 2019/11/14.
//  Copyright © 2019 comsenz-service.com. All rights reserved.
//

#import "AppDelegate.h"


@interface AppDelegate (iflyMSC)

-(void)launchXFSpeech;


@end


