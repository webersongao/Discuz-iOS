//
//  AttachmentBar.h
//  DiscuzMobile
//
//  Created by HB on 2017/6/6.
//  Copyright © 2017年 comsenz-service.com.  All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AttachmentBar : UIView

@property (nonatomic, strong) UIButton *imageBtn;

@end
