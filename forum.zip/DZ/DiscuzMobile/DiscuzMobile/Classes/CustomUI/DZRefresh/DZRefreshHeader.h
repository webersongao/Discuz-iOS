//
//  PRRefreshHeader.h
//  PandaReader
//
//  Created by changle on 2018/3/30.
//

#import "MJRefreshGifHeader.h"

@interface DZRefreshHeader : MJRefreshGifHeader


- (void)checkRestartLoadingAnimation;

@end
