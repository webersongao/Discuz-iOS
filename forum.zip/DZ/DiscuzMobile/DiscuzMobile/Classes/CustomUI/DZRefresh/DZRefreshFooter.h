//
//  DZRefreshFooter.h
//  PandaReader
//
//  Created by WebersonGao on 2019/4/11.
//  Copyright © 2019 ZHWenXue. All rights reserved.
//

#import "MJRefreshAutoGifFooter.h"

NS_ASSUME_NONNULL_BEGIN

@interface DZRefreshFooter : MJRefreshAutoGifFooter

@end

NS_ASSUME_NONNULL_END
