//
//  addressModel.m
//  省市区model
//
//  Created by 耿远风 on 17/7/13.
//  Copyright © 2017年 耿远风. All rights reserved.
//

#import "addressModel.h"

@implementation addressModel

@end
